# Select default algorithm
from .izzo import lambert

__all__ = ["lambert"]
